﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
                ViewBag.BaseballLeagues = context.Leagues
                        .Where(l => l.Sport.Contains("Baseball"));
                ViewBag.WomenLeagues =  context.Leagues
                        .Where(l => l.Name.Contains("Womens'")).ToList();
        return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
                ViewBag.WomenLeagues =  context.Leagues
                        .Where(l => l.Name.Contains("Womens'")).ToList();
                ViewBag.HockeyLeagues =  context.Leagues
                        .Where(l => l.Name.Contains("Hockey")).ToList();
                ViewBag.OtherThanfootball = context.Leagues
                        .Where(p => p.Sport != "Football").ToList();
                ViewBag.ConferenceLeagues =  context.Leagues
                        .Where(l => l.Name.Contains("Conference")).ToList();
                ViewBag.LostLeaguesOfAtlantis =  context.Leagues
                        .Where(l => l.Name.Contains("Atlantic")).ToList();
                ViewBag.Dallasbehatin =  context.Teams
                        .Where(l => l.Location.Contains("Dallas")).ToList();
                ViewBag.WhereRaptorslit =  context.Teams
                        .Where(l => l.TeamName.Contains("Raptors")).ToList();
                ViewBag.Raptorslit =  context.Teams
                        .Where(l => l.Location.Contains("City")).ToList();
                ViewBag.ThereIsATinTeams = context.Teams
                        .Where(t => t.TeamName[0] =='T').ToList();
                ViewBag.AllTeamsAlpha = context.Teams
                        .OrderByDescending(p => p.Location).ToList();
                ViewBag.AllTeamsAlpha = context.Teams
                        .OrderByDescending(p => p.TeamName).ToList();
                ViewBag.AllNamesCooper = context.Players
                        .Where(p => p.LastName == "Cooper").ToList();
                ViewBag.AllNamesJoshua = context.Players
                        .Where(p => p.FirstName == "Joshua").ToList();
                        // .Where(p => p.FirstName != "Joshua").ToList();
                ViewBag.AllNamesCJ = context.Players
                        .Where(p => p.LastName == "Cooper").ToList()
                        .Where(p => p.FirstName != "Joshua").ToList();
                ViewBag.AllNamesAlWY = context.Players
                        .Where(p => p.FirstName == "Alexander").ToList();
        return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
                ViewBag.AllTeamsAtlantic = context.Teams
                        .Include(t => t.CurrLeague)
                        .Where(t => t.CurrLeague.Name == "Atlantic Soccer Conference")
                        .ToList();
                ViewBag.Dallasbehatin = context.Teams
                        .Include(p => p.CurrentPlayers)
                        .FirstOrDefault(a => a.TeamName == "Penguins");
                ViewBag.Sophia = context.Players
                        .Include(p => p.CurrentTeam)
                        .Where(p => p.FirstName == "Sophia")
                        .ToList();
                ViewBag.Colligatebasket = context.Teams
                        .Include(t => t.CurrLeague)
                        .Where(t => t.CurrLeague.Name == "International Collegiate Baseball Conference")
                        .ToList();
                ViewBag.AllFootballColli = context.Teams
                        .Include(t => t.CurrLeague)
                        .Where(t => t.CurrLeague.Name == "American Conference of Amateur Football")
                        .ToList();
                ViewBag.AllFootball = context.Teams
                        .Where(p => p.CurrLeague.Sport == "Football")
                        .ToList();
                ViewBag.Noflores = context.Players
                        .Include(p => p.CurrentTeam)
                        .Where(p => p.LastName != "Flores")
                        .ToList();
                ViewBag.Manitoba = context.Teams
                        .Include(t =>t.CurrentPlayers)
                        .FirstOrDefault(pt => pt.TeamName =="Tiger-Cats" );
                ViewBag.twelveteams = context.Teams
                        .Include(t => t.AllPlayers)
                        .Include(t => t.CurrLeague)
                        .OrderByDescending(t => t.AllPlayers.Count)
                        .Where(t => t.AllPlayers.Count > 11)
                        .ToList();

                return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
                return View();
        }

        }
}