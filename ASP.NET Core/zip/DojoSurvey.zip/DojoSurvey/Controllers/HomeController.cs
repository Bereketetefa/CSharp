using System;
using Microsoft.AspNetCore.Mvc;

namespace HelloWorld.Controllers     
{
    public class HomeController : Controller   
    {
        [HttpGet("")]
        public ViewResult Index()
        {
            return View();
        }


        [HttpPost("/process")]
        public IActionResult Process(string Name, string Location, string Language, string Description)
        {
            Console.WriteLine($"{Name} | {Location} | {Language} | {Description}");
            // return Redirect("/");
            ViewBag.Name = Name;
            ViewBag.Location = Location;
            ViewBag.Language = Language;
            ViewBag.Description = Description;
            return View("Results");
        }
    }
}