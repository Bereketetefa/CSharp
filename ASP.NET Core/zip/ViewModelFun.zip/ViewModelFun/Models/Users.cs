using System.Collections.Generic;

namespace Users.Models
{ 
    public class User
    {
        public string Users {get;set;}

    }
}